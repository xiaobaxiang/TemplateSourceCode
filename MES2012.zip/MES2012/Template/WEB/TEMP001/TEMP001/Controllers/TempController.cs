﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TEMP001.Controllers
{
    public class TempController : Controller
    {        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult signin()
        {
            return View();
        }

        public ActionResult validation()
        {
            return View();
        }

        public ActionResult blank()
        {
            return View();
        }

        public ActionResult basic()
        {
            return View();
        }
      
        public ActionResult TableBasic()
        {
            return View();
        }

        public ActionResult TableResponsive()
        {
            return View();
        }

        public ActionResult TablesAdvanced()
        {
            return View();
        }

        public ActionResult Buttons()
        {
            return View();
        }

        public ActionResult Portlets()
        {
            return View();
        }

        public ActionResult Widgets()
        {
            return View();
        }
        
    }
}
