﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TEMP001.Controllers
{
    public class BASController : BaseController
    {       
        public ActionResult BAS001()
        {
            return View(userModel);
        }

    }
}
