﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MESIII;

namespace TEMP001.Controllers
{
    public class SYSController : BaseController
    {     
        public ActionResult SYS001()
        {
            return View(userModel);
        }

        public ActionResult SYS002()
        {
            return View(userModel);
        }

        public ActionResult SYS981()
        {
            return View(userModel);
        }

        #region //Retrieval
        #region //QryDomainInfo001
        public void QryDomainInfo001(string DOMAIN_NO, int PAGE_INDEX = -1, int PAGE_SIZE = -1, string ORDER_BY = "")
        {
            try
            {
                string sParam = "<root><DOMAIN_INFO>";
                sParam += "<DOMAIN_NO>" + DOMAIN_NO + "</DOMAIN_NO>";
                sParam += "</DOMAIN_INFO>";
                sParam += "<PAGE_INFO>";
                sParam += "<PAGE_INDEX>" + PAGE_INDEX + "</PAGE_INDEX>";
                sParam += "<PAGE_SIZE>" + PAGE_SIZE + "</PAGE_SIZE>";
                sParam += "<ORDER_BY>" + ORDER_BY + "</ORDER_BY>";
                sParam += "</PAGE_INFO>";
                sParam += "</root>";
                DataSet oDS = web.ctEnumerateData("SYSSO.QryDomainInfo001", sParam);
                string sData = CmnSrvLib.Dtb2Json(oDS.Tables[0]).ToString();
                int TOTAL_COUNT = cmn.cap_int(oDS.Tables["TABLE_ROWS"].Rows[0]["TOTAL_COUNT"]);
                res = "{\"status\" : \"success\",\"msg\": \"OK\",\"table_rows\": \"" + TOTAL_COUNT + "\",\"qrydata\":" + sData + "}";
            }
            catch (Exception e1)
            {
                string error_message = Microsoft.JScript.GlobalObject.escape(e1.Message);
                res = "{\"status\" : \"error\",\"msg\": \"error\",\"error_desc\":\"" + error_message + "\"}";
            }

            Response.Write(res);
        }
        #endregion
        #endregion

        #region //Transaction
        #region //TxDomainInfo001
        public void TxDomainInfo001(string TxType, string DOMAIN_NO, string DOMAIN_NAME_CH, string DOMAIN_NAME_EN, int DOMAIN_SEQ)
        {
            try
            {
                string sParam = "<root><DOMAIN_INFO>";
                sParam += "<DOMAIN_NO>" + DOMAIN_NO + "</DOMAIN_NO>";
                sParam += "<DOMAIN_NAME_CH>" + DOMAIN_NAME_CH + "</DOMAIN_NAME_CH>";
                sParam += "<DOMAIN_NAME_EN>" + DOMAIN_NAME_EN + "</DOMAIN_NAME_EN>";
                sParam += "<DOMAIN_SEQ>" + DOMAIN_SEQ + "</DOMAIN_SEQ>";
                sParam += "</DOMAIN_INFO></root>";
                switch (TxType)
                {
                    case "A": nResult = web.ctPostTxact("SYSSO.TxDomainInfo001", sParam, TxTypeConsts.TxTypeAddNew); break;
                    case "D": nResult = web.ctPostTxact("SYSSO.TxDomainInfo001", sParam, TxTypeConsts.TxTypeDelete); break;
                    case "U": nResult = web.ctPostTxact("SYSSO.TxDomainInfo001", sParam, TxTypeConsts.TxTypeUpdate); break;
                    default: throw new MyException("transaction type error!");
                }
                if (nResult > 0) { res = "{\"status\" : \"success\",\"msg\": \"OK\",\"qrydata\":\"" + nResult + "\"}"; }
            }
            catch (Exception e1)
            {
                string error_message = Microsoft.JScript.GlobalObject.escape(e1.Message);
                res = "{\"status\" : \"error\",\"msg\": \"error\",\"error_desc\":\"" + error_message + "\"}";
            }
            Response.Write(res);
        }
        #endregion
        #endregion
    }
}
