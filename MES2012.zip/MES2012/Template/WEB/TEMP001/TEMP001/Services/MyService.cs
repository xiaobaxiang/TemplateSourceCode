﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace TEMP001.Services
{
    public struct ToJsonDoamin
    {
        public string DOMAIN_NO { get; set; }
        public string DOMAIN_NAME_EN { get; set; }
        public string DOMAIN_NAME_CH { get; set; }
        public int DOMAIN_SEQ { get; set; }
    }

    public class MyService
    {
        
    }
}