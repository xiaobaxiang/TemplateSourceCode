﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using MESIII;

namespace SYSSO
{
    public class Retrieval : ISDServer.IRetrieval
    {
        public DataSet Execute(IProcess oContext, string sServiceID, string sParams, int nServerID, int nPageIndex, int nPageSize)
        {
            DataSet ds = null;
            try
            {
                TArgsRV oArgsRv = new TArgsRV();
                oArgsRv.ServiceID = sServiceID;
                oArgsRv.PageIndex = nPageIndex;
                oArgsRv.PageSize = nPageSize;
                oArgsRv.Param = sParams;
                oArgsRv.Context = oContext;
                oArgsRv.Connecion = oContext.CNEstablish("SYSSO", nServerID);
                oArgsRv.Command = oContext.CMD("SYSSO", nServerID);
                //****************************************************************
                SYSRv Qry = new SYSRv();
                //****************************************************************
                switch (sServiceID)
                {
                    case "QryLogin001": ds = Qry.QryLogin001(oArgsRv); break;
                    case "QryUserDomain001": ds = Qry.QryUserDomain001(oArgsRv); break;
                    case "QryUserPackage001": ds = Qry.QryUserPackage001(oArgsRv); break;
                    case "QryUserProgram001": ds = Qry.QryUserProgram001(oArgsRv); break;
                    case "QryDomainInfo001": ds = Qry.QryDomainInfo001(oArgsRv); break;
                    case "QryPackageInfo001": ds = Qry.QryPackageInfo001(oArgsRv); break;
                    case "QryProgramInfo001": ds = Qry.QryProgramInfo001(oArgsRv); break;
                    default: throw new SystemException("Unkown retrieval specifier [ " + sServiceID + " ] !!");
                }
                return ds;
            }
            catch (MyException e)
            {
                throw e;
            }
        }

        class SYSRv
        {
            CmnSrvLib cmn = new CmnSrvLib(0);
            DataSet oResult = new DataSet("root");
            string qry = "", sql = "";

            #region //QryLogin001 -- QUERY LOGIN DATA -- boly 2016-01-01
            public DataSet QryLogin001(TArgsRV oArgsRv)
            {
                OleDbCommand cmd = oArgsRv.Command;
                qry = oArgsRv.ServiceID;
                //****************************************************************
                XmlDocument x = new XmlDocument();
                x.LoadXml(oArgsRv.Param);
                string LOGIN_NO = cmn.ParserXML(x, "//LOGIN_INFO/LOGIN_NO");
                string LOGIN_PWD = cmn.ParserXML(x, "//LOGIN_INFO/LOGIN_PWD");
                string CLIENT_SESSION = cmn.ParserXML(x, "//LOGIN_INFO/CLIENT_SESSION");
                string CLIENT_IP = cmn.ParserXML(x, "//LOGIN_INFO/CLIENT_IP");
                int PAGE_INDEX = cmn.ParserXML(x, "//PAGE_INFO/PAGE_INDEX", -1, false);
                int PAGE_SIZE = cmn.ParserXML(x, "//PAGE_INFO/PAGE_SIZE", oArgsRv.PageSize, false);
                string ORDER_BY = cmn.ParserXML(x, "//PAGE_INFO/ORDER_BY", false);
                //****************************************************************
                if (LOGIN_NO.Equals("")) { throw new MyException(999, qry, "FIELD [LOGIN NO] CANNOT EMPTY!"); }
                if (LOGIN_PWD.Equals("")) { throw new MyException(999, qry, "FIELD [LOGIN PWD] CANNOT EMPTY!"); }
                if (CLIENT_IP.Equals("")) { throw new MyException(999, qry, "FIELD [CLIENT IP] CANNOT EMPTY!"); }

                LOGIN_PWD = new ISDServer().MyEncode01(LOGIN_PWD);

                #region //CHECK LOGIN DATA
                sql = "SELECT a.USER_ID,a.PASSWORD,a.USER_NAME_CH,a.USER_NAME_EN,a.EMAIL,a.STATUS_NO";
                sql += ",b.ROLE_ID";
                sql += ",c.ROLE_NAME_CH,c.ROLE_NAME_EN";
                sql += ",0 AS LOGIN_COUNT,'' AS LOGIN_TIME";
                sql += " FROM BAS.USER_INFO a";
                sql += " LEFT JOIN BAS.ROLE_USER b ON a.USER_ID = b.USER_ID";
                sql += " LEFT JOIN BAS.ROLE_INFO c ON b.ROLE_ID = c.ROLE_ID";
                sql += " WHERE a.LOGIN_NO = " + cmn.SQLQ(LOGIN_NO);
                oResult = cmn.CmnRvEnumerate(sql, cmd, oArgsRv.ServiceID, PAGE_INDEX, PAGE_SIZE);
                if (!cmn.CheckEOF(oResult)) { throw new MyException(999, qry, "CANNOT FOUND LOGIN DATA!", LOGIN_NO); }

                int nUserID = Convert.ToInt32(oResult.Tables[0].Rows[0]["USER_ID"]);
                string sPassword = oResult.Tables[0].Rows[0]["PASSWORD"].ToString();
                string STATUS_NO = oResult.Tables[0].Rows[0]["STATUS_NO"].ToString();

                if (STATUS_NO.Equals("S")) { throw new MyException(999, qry, "THIS USER STOPED,CANNOT USE!", LOGIN_NO); }
                if (!LOGIN_PWD.Equals(sPassword)) { throw new MyException(999, qry, "LOGIN PASSWEORD FAIL!"); }
                #endregion

                sql = "SELECT SESSION_ID,LOGIN_TIME FROM BAS.TRACE_INFO";
                sql += " WHERE USER_ID = " + cmn.SQLQ(nUserID);
                sql += " ORDER BY CREATE_DATE DESC";
                DataSet oDS = cmn.CmnRvEnumerate(sql, cmd);
                if (cmn.CheckEOF(oDS))
                {
                    oResult.Tables[0].Rows[0]["LOGIN_COUNT"] = cmn.cap_int(oDS.Tables[0].Rows.Count) + 1;
                    oResult.Tables[0].Rows[0]["LOGIN_TIME"] = cmn.cap_datetime(oDS.Tables[0].Rows[0]["LOGIN_TIME"]);
                    oResult.AcceptChanges();
                }
                else
                {
                    oResult.Tables[0].Rows[0]["LOGIN_TIME"] = cmn.cap_datetime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    oResult.AcceptChanges();
                }

                string sParam = "<root><TRACE_INFO>";
                sParam += "<USER_ID>" + nUserID + "</USER_ID>";
                sParam += "<PRO_NO>" + oArgsRv.ServiceID + "</PRO_NO>";
                sParam += "<SERVICE_NAME>" + oArgsRv.ServiceID + "</SERVICE_NAME>";
                sParam += "<SERVICE_TYPE>WEB</SERVICE_TYPE>";
                sParam += "<CLIENT_IP>" + CLIENT_IP + "</CLIENT_IP>";
                sParam += "<SESSION_ID>" + CLIENT_SESSION + "</SESSION_ID>";
                sParam += "</TRACE_INFO></root>";
                int nResult = oArgsRv.Context.DAPostTxact("SYSSO.TxTraceInfo001", sParam, TxTypeConsts.TxTypeAddNew, oArgsRv.Context.ServerID("SYSSO"),null);

                #region //GET USER_DOMAIN
                sql = "SELECT a.DOMAIN_NO,a.DOMAIN_NAME_EN,a.DOMAIN_NAME_CH,a.DOMAIN_SEQ";
                sql += " FROM BAS.DOMAIN_INFO a , BAS.USER_DOMAIN b";
                sql += " WHERE a.DOMAIN_NO = b.DOMAIN_NO";
                sql += " AND b.USER_ID = " + cmn.SQLQ(nUserID);
                sql += " ORDER BY a.DOMAIN_SEQ";
                DataSet oUserDomain = cmn.CmnRvEnumerate(sql, cmd, "USER_DOMAIN", -1, -1);
                oResult.Merge(oUserDomain.Tables[0]);
                #endregion

                #region //GET USER_PACKAGE
                sql = "SELECT a.USER_ID,a.PACK_NO,CASE WHEN ISNULL(a.REF_PACK,'')='' THEN a.PACK_NO ELSE a.REF_PACK END REF_PACK";
                sql += ",b.PACK_NAME_CH,b.PACK_NAME_EN,b.DOMAIN_NO,b.PACK_SEQ";
                sql += " FROM BAS.USER_PACKAGE a , BAS.PACKAGE_INFO b";
                sql += " WHERE a.PACK_NO = b.PACK_NO";
                sql += " AND a.USER_ID = " + cmn.SQLQ(nUserID);
                sql += " ORDER BY b.PACK_SEQ";
                DataSet oUserPackage = cmn.CmnRvEnumerate(sql, cmd, "USER_PACKAGE", -1, -1);
                oResult.Merge(oUserPackage.Tables[0]);
                #endregion

                #region //GET USER_PROGRAM
                sql = "SELECT a.USER_ID,a.PRO_NO";
                sql += ",a.PRIVILEGE,a.FUN_CODE";
                sql += ",b.PACK_NO,b.PRO_NAME_CH,b.PRO_NAME_EN,b.PRO_PATH,CASE WHEN ISNULL(b.REF_PACK,'')='' THEN b.PACK_NO ELSE b.REF_PACK END REF_PACK,b.REF_PRO,b.PRO_SEQ,b.FUN_LIST";
                sql += ",c.DOMAIN_NO,c.PACK_NAME_CH,c.PACK_NAME_EN";
                sql += ",d.DOMAIN_NAME_CH,d.DOMAIN_NAME_EN";
                sql += " FROM BAS.USER_PROGRAM a , BAS.PROGRAM_INFO b , BAS.PACKAGE_INFO c , BAS.DOMAIN_INFO d";
                sql += " WHERE a.PRO_NO = b.PRO_NO AND b.PACK_NO = c.PACK_NO";
                sql += " AND c.DOMAIN_NO = d.DOMAIN_NO";
                sql += " AND a.USER_ID = " + cmn.SQLQ(nUserID);
                sql += " ORDER BY b.PRO_SEQ";
                DataSet oUserProgram = cmn.CmnRvEnumerate(sql, cmd, "USER_PROGRAM", -1, -1);
                oResult.Merge(oUserProgram.Tables[0]);
                #endregion

                return oResult;
            }
            #endregion          

            #region //QryUserDomain001 -- QUERY USER_DOMAIN DATA -- boly 2016-01-01
            public DataSet QryUserDomain001(TArgsRV oArgsRv)
            {
                OleDbCommand cmd = oArgsRv.Command;
                qry = oArgsRv.ServiceID;
                //****************************************************************
                XmlDocument x = new XmlDocument();
                x.LoadXml(oArgsRv.Param);
                int USER_ID = cmn.ParserXML(x, "//USER_DOMAIN/USER_ID", -1);
                int PAGE_INDEX = cmn.ParserXML(x, "//PAGE_INFO/PAGE_INDEX", -1, false);
                int PAGE_SIZE = cmn.ParserXML(x, "//PAGE_INFO/PAGE_SIZE", oArgsRv.PageSize, false);
                string ORDER_BY = cmn.ParserXML(x, "//PAGE_INFO/ORDER_BY", false);
                //****************************************************************
                sql = "SELECT a.DOMAIN_NO,a.DOMAIN_NAME_EN,a.DOMAIN_NAME_CH,a.DOMAIN_SEQ";
                sql += " FROM BAS.DOMAIN_INFO a , BAS.USER_DOMAIN b";
                sql += " WHERE a.DOMAIN_NO = b.DOMAIN_NO";
                sql += " AND b.USER_ID = " + cmn.SQLQ(USER_ID);

                sql += (!ORDER_BY.Equals("") ? " ORDER BY " + ORDER_BY : " ORDER BY a.DOMAIN_SEQ");
                oResult = cmn.CmnRvEnumerate(sql, cmd, "USER_DOMAIN", PAGE_INDEX, PAGE_SIZE);
                return oResult;
            }
            #endregion

            #region //QryUserPackage001 -- QUERY USER_PACKAGE DATA -- boly 2016-01-01
            public DataSet QryUserPackage001(TArgsRV oArgsRv)
            {
                OleDbCommand cmd = oArgsRv.Command;
                qry = oArgsRv.ServiceID;
                //****************************************************************
                XmlDocument x = new XmlDocument();
                x.LoadXml(oArgsRv.Param);
                int USER_ID = cmn.ParserXML(x, "//USER_PACKAGE/USER_ID", -1);
                string DOMAIN_NO = cmn.ParserXML(x, "//USER_PACKAGE/DOMAIN_NO");
                int PAGE_INDEX = cmn.ParserXML(x, "//PAGE_INFO/PAGE_INDEX", -1, false);
                int PAGE_SIZE = cmn.ParserXML(x, "//PAGE_INFO/PAGE_SIZE", oArgsRv.PageSize, false);
                string ORDER_BY = cmn.ParserXML(x, "//PAGE_INFO/ORDER_BY", false);
                //****************************************************************
                sql = "SELECT a.USER_ID,a.PACK_NO,CASE WHEN ISNULL(a.REF_PACK,'')='' THEN a.PACK_NO ELSE a.REF_PACK END REF_PACK";
                sql += ",b.PACK_NAME_CH,b.PACK_NAME_EN,b.DOMAIN_NO,b.PACK_SEQ";
                sql += " FROM BAS.USER_PACKAGE a , BAS.PACKAGE_INFO b";
                sql += " WHERE a.PACK_NO = b.PACK_NO";
                sql += " AND a.USER_ID = " + cmn.SQLQ(USER_ID);

                if (!DOMAIN_NO.Equals("")) { sql += " AND b.DOMAIN_NO = " + cmn.SQLQ(DOMAIN_NO); }

                sql += (!ORDER_BY.Equals("") ? " ORDER BY " + ORDER_BY : " ORDER BY b.PACK_SEQ");
                oResult = cmn.CmnRvEnumerate(sql, cmd, "USER_PACKAGE", PAGE_INDEX, PAGE_SIZE);
                return oResult;
            }
            #endregion

            #region //QryUserProgram001 -- QUERY USER_PROGRAM DATA -- boly 2016-01-01
            public DataSet QryUserProgram001(TArgsRV oArgsRv)
            {
                OleDbCommand cmd = oArgsRv.Command;
                qry = oArgsRv.ServiceID;
                //****************************************************************
                XmlDocument x = new XmlDocument();
                x.LoadXml(oArgsRv.Param);
                int USER_ID = cmn.ParserXML(x, "//USER_PROGRAM/USER_ID", -1);
                string PACK_NO = cmn.ParserXML(x, "//USER_PROGRAM/PACK_NO");
                int PAGE_INDEX = cmn.ParserXML(x, "//PAGE_INFO/PAGE_INDEX", -1, false);
                int PAGE_SIZE = cmn.ParserXML(x, "//PAGE_INFO/PAGE_SIZE", oArgsRv.PageSize, false);
                string ORDER_BY = cmn.ParserXML(x, "//PAGE_INFO/ORDER_BY", false);
                //****************************************************************
                sql = "SELECT a.USER_ID,a.PRO_NO";
                sql += ",a.PRIVILEGE,a.FUN_CODE";
                sql += ",b.PACK_NO,b.PRO_NAME_CH,b.PRO_NAME_EN,b.PRO_PATH,CASE WHEN ISNULL(b.REF_PACK,'')='' THEN b.PACK_NO ELSE b.REF_PACK END REF_PACK,b.REF_PRO,b.PRO_SEQ,b.FUN_LIST";
                sql += ",c.DOMAIN_NO,c.PACK_NAME_CH,c.PACK_NAME_EN";
                sql += ",d.DOMAIN_NAME_CH,d.DOMAIN_NAME_EN";
                sql += " FROM BAS.USER_PROGRAM a , BAS.PROGRAM_INFO b , BAS.PACKAGE_INFO c , BAS.DOMAIN_INFO d";
                sql += " WHERE a.PRO_NO = b.PRO_NO AND b.PACK_NO = c.PACK_NO";
                sql += " AND c.DOMAIN_NO = d.DOMAIN_NO";
                sql += " AND a.USER_ID = " + cmn.SQLQ(USER_ID);

                if (!PACK_NO.Equals("")) { sql += " AND b.PACK_NO = " + cmn.SQLQ(PACK_NO); }

                sql += (!ORDER_BY.Equals("") ? " ORDER BY " + ORDER_BY : " ORDER BY b.PRO_SEQ");
                oResult = cmn.CmnRvEnumerate(sql, cmd, "USER_PROGRAM", PAGE_INDEX, PAGE_SIZE);
                return oResult;
            }
            #endregion

            #region //QryDomainInfo001 -- QUERY DOMAIN_INFO DATA -- boly 2016-01-01
            public DataSet QryDomainInfo001(TArgsRV oArgsRv)
            {
                OleDbCommand cmd = oArgsRv.Command;
                qry = oArgsRv.ServiceID;
                //****************************************************************
                XmlDocument x = new XmlDocument();
                x.LoadXml(oArgsRv.Param);
                string DOMAIN_NO = cmn.ParserXML(x, "//DOMAIN_INFO/DOMAIN_NO");
                int PAGE_INDEX = cmn.ParserXML(x, "//PAGE_INFO/PAGE_INDEX", -1, false);
                int PAGE_SIZE = cmn.ParserXML(x, "//PAGE_INFO/PAGE_SIZE", oArgsRv.PageSize, false);
                string ORDER_BY = cmn.ParserXML(x, "//PAGE_INFO/ORDER_BY", false);
                //****************************************************************
                sql = "SELECT DOMAIN_NO,DOMAIN_NAME_EN,DOMAIN_NAME_CH,DOMAIN_SEQ";
                sql += " FROM BAS.DOMAIN_INFO";
                sql += " WHERE DOMAIN_NO IS NOT NULL";

                if (!DOMAIN_NO.Equals("")) { sql += " AND DOMAIN_NO = " + cmn.SQLQ(DOMAIN_NO); }
                
                sql += (!ORDER_BY.Equals("") ? " ORDER BY " + ORDER_BY : " ORDER BY DOMAIN_SEQ");
                oResult = cmn.CmnRvEnumerate(sql, cmd, oArgsRv.ServiceID, PAGE_INDEX, PAGE_SIZE);
                return oResult;
            }
            #endregion

            #region //QryPackageInfo001 QUERY PACKAGE_INFO DATA -- boly 2016-01-01
            public DataSet QryPackageInfo001(TArgsRV oArgsRv)
            {
                OleDbCommand cmd = oArgsRv.Command;
                qry = oArgsRv.ServiceID;
                //****************************************************************
                XmlDocument x = new XmlDocument();
                x.LoadXml(oArgsRv.Param);
                string DOMAIN_NO = cmn.ParserXML(x, "//PACKAGE_INFO/DOMAIN_NO");
                string PACK_NO = cmn.ParserXML(x, "//PACKAGE_INFO/PACK_NO");
                int PAGE_INDEX = cmn.ParserXML(x, "//PAGE_INFO/PAGE_INDEX", -1, false);
                int PAGE_SIZE = cmn.ParserXML(x, "//PAGE_INFO/PAGE_SIZE", oArgsRv.PageSize, false);
                string ORDER_BY = cmn.ParserXML(x, "//PAGE_INFO/ORDER_BY", false);
                //****************************************************************
                sql = "SELECT a.DOMAIN_NO,a.PACK_NO,a.PACK_NAME_EN,a.PACK_NAME_CH,a.REF_PACK,a.PACK_SEQ";
                sql += ",b.DOMAIN_NAME_CH,b.DOMAIN_NAME_EN,b.DOMAIN_SEQ";
                sql += " FROM BAS.PACKAGE_INFO a , BAS.DOMAIN_INFO b";
                sql += " WHERE a.DOMAIN_NO = b.DOMAIN_NO";

                if (!DOMAIN_NO.Equals("")) { sql += " AND a.DOMAIN_NO = " + cmn.SQLQ(DOMAIN_NO); }
                if (!PACK_NO.Equals("")) { sql += " AND a.PACK_NO = " + cmn.SQLQ(PACK_NO); }

                sql += (!ORDER_BY.Equals("") ? " ORDER BY " + ORDER_BY : " ORDER BY b.DOMAIN_SEQ,a.PACK_SEQ");
                oResult = cmn.CmnRvEnumerate(sql, cmd, oArgsRv.ServiceID, PAGE_INDEX, PAGE_SIZE);
                return oResult;
            }
            #endregion

            #region //QryProgramInfo001 -- QUERY PROGRAM_INFO DATA -- boly 2016-01-01
            public DataSet QryProgramInfo001(TArgsRV oArgsRv)
            {
                OleDbCommand cmd = oArgsRv.Command;
                qry = oArgsRv.ServiceID;
                //****************************************************************
                XmlDocument x = new XmlDocument();
                x.LoadXml(oArgsRv.Param);
                string PACK_NO = cmn.ParserXML(x, "//PROGRAM_INFO/PACK_NO");
                string PRO_NO = cmn.ParserXML(x, "//PROGRAM_INFO/PRO_NO");
                int PAGE_INDEX = cmn.ParserXML(x, "//PAGE_INFO/PAGE_INDEX", -1, false);
                int PAGE_SIZE = cmn.ParserXML(x, "//PAGE_INFO/PAGE_SIZE", oArgsRv.PageSize, false);
                string ORDER_BY = cmn.ParserXML(x, "//PAGE_INFO/ORDER_BY", false);
                //****************************************************************
                sql = "SELECT a.PACK_NO,a.PRO_NO,a.PRO_PATH,a.PRO_NAME_EN,a.PRO_NAME_CH,a.PRO_SEQ";
                sql += ",a.PRO_PATH,a.REF_PRO,CASE WHEN ISNULL(a.REF_PACK,'')='' THEN a.PACK_NO ELSE a.REF_PACK END REF_PACK,a.PRO_TYPE";
                sql += ",a.VER_MAJOR,a.VER_MINOR,a.VER_REVISOR";
                sql += ",a.FUN_LIST,a.FUN_CODE";
                sql += ",b.DOMAIN_NO,b.PACK_NAME_EN,b.PACK_NAME_CH,b.PACK_SEQ";
                sql += " FROM BAS.PROGRAM_INFO a , BAS.PACKAGE_INFO b";
                sql += " WHERE a.PACK_NO = b.PACK_NO";

                if (!PACK_NO.Equals("")) { sql += " AND a.PACK_NO = " + cmn.SQLQ(PACK_NO); }
                if (!PRO_NO.Equals("")) { sql += " AND a.PRO_NO = " + cmn.SQLQ(PRO_NO); }

                sql += (!ORDER_BY.Equals("") ? " ORDER BY " + ORDER_BY : " ORDER BY b.PACK_SEQ,a.PRO_SEQ");
                oResult = cmn.CmnRvEnumerate(sql, cmd, oArgsRv.ServiceID, PAGE_INDEX, PAGE_SIZE);
                return oResult;
            }
            #endregion
        }
    }
}
