﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using TEMP001;
using TEMP001.Models;
using MESIII;
using NPOI.HSSF.UserModel;
using NPOI.HSSF.Util;
using NPOI.SS.Util;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace TEMP001
{
    public class BaseController : Controller
    {
        public int SERVER_ID { set; get; }
        public ISDWeb web;
        public CmnSrvLib cmn = new CmnSrvLib();
        public UserModel userModel = new UserModel();
        public string res = "";
        public int nResult = -1;

        public BaseController()
        {
            userModel.CURR_DOMAIN = "";
            userModel.CURR_DOMAIN_NAME = "";
            userModel.CURR_PACKAGE = "";
            userModel.CURR_PACKAGE_NAME = "";
            userModel.CURR_PROGRAM = "";
            userModel.CURR_PROGRAM_NAME = "";
        }

        public BaseController(System.Web.Routing.RequestContext requestContext)
        {
            SERVER_ID = int.Parse(this.HttpContext.Session["SERVER_ID"].ToString());
            this.OnInit(requestContext);
        }

        public virtual void OnInit(System.Web.Routing.RequestContext requestContext)
        {
            if (requestContext.HttpContext.Session["USER_ID"] != null)
            {
                //UserState userState = requestContext.HttpContext.Session["UserState"] as UserState;
                //string passCode = requestContext.HttpContext.Request.Cookies["UserState"].Value.Trim();
                string controllerName = requestContext.RouteData.Values["controller"].ToString() + "Controller";
                string actionName = requestContext.RouteData.Values["action"].ToString();
                //判断有没有Action操作权限               
                //userState.AuthCollection.Contains(controllerName + "/" + acitonName);            
            }
            else
            {                   
                requestContext.HttpContext.Response.Redirect("~/");
            }
        }
          
        public virtual void OnInit()
        {
            if (this.HttpContext.Session["SERVER_ID"] == null)
            {
                this.HttpContext.Response.Redirect("~/");
            }
            else
            {
                SERVER_ID = int.Parse(this.HttpContext.Session["SERVER_ID"].ToString());
                web = new ISDWeb(SERVER_ID);
                string controllerName = this.RouteData.Values["controller"].ToString().ToUpper();
                string actionName = this.RouteData.Values["action"].ToString().ToUpper();

                string CHECK_FLAG = "Y";

                if (actionName.Length > 1)
                {
                    if (actionName.Length > 5) { if (actionName.Substring(0, 5).Equals("EXCEL")) { CHECK_FLAG = "N"; } }
                    if (actionName.Substring(0, 2).Equals("TX")) { CHECK_FLAG = "N"; }
                    if (actionName.Substring(0, 3).Equals("QRY")) { CHECK_FLAG = "N"; }
                }
                else
                {
                    CHECK_FLAG = "N";
                }

                if (CHECK_FLAG.Equals("Y"))
                {
                    switch (controllerName + "_" + actionName)
                    {
                        case "HOME_FRONTEND": break;
                        case "HOME_INDEX": break;
                        case "HOME_LOGIN":
                            if (Convert.ToInt64(this.HttpContext.Session["USER_ID"]) > -1) { this.HttpContext.Response.Redirect("~/Home/Welcome"); }
                            break;
                        case "HOME_TEMP": break;
                        case "HOME_NOTFOUND": break;
                        case "HOME_QRYTIME001": break;
                        case "SYS_LOGINBANNER": break;
                        case "SYS_LOGINBANNERPDA": break;
                        case "SYS_USERMENU": break;
                        case "HOME_PAGEVAILDCODE": break;
                        case "SYS_QRYBULLETININFO": break;
                        case "SYS_TXLOGIN": break;
                        case "SYS_TXLOGOUT": break;
                        case "SYS_TXPDALOGIN": break;
                        //case "bas": break;

                        default:
                            //这里实现用户信息的相关验证业务            
                            if (this.HttpContext.Session["USER_ID"] != null)
                            {
                                if (Convert.ToInt64(this.HttpContext.Session["USER_ID"]) > -1)
                                {
                                    try
                                    {
                                        XmlDocument xmlDomain = new XmlDocument();
                                        xmlDomain.LoadXml(this.HttpContext.Session["USER_DOMAIN"].ToString());

                                        XmlDocument xmlPackage = new XmlDocument();
                                        xmlPackage.LoadXml(this.HttpContext.Session["USER_PACKAGE"].ToString());

                                        XmlDocument xmlProgram = new XmlDocument();
                                        xmlProgram.LoadXml(this.HttpContext.Session["USER_PROGRAM"].ToString());

                                        #region //GET PRIVILEGE DATA
                                        if (Request["CURR_DOMAIN"] != null)
                                        {
                                            userModel.CURR_DOMAIN = cmn.cap_string(Request["CURR_DOMAIN"]);

                                            XmlNodeList ns = xmlDomain.SelectNodes("//root/USER_DOMAIN");
                                            foreach (XmlNode node in ns)
                                            {
                                                string sDomainNO = node.SelectSingleNode("DOMAIN_NO").InnerText.ToString();
                                                if (userModel.CURR_DOMAIN.Equals(node.SelectSingleNode("DOMAIN_NO").InnerText.ToString()))
                                                {
                                                    userModel.CURR_DOMAIN_NAME = node.SelectSingleNode("DOMAIN_NAME_CH").InnerText.ToString();
                                                    break;
                                                }
                                            }
                                        }
                                        if (Request["PRO_NO"] != null) { actionName = cmn.cap_string(Request["PRO_NO"]); }
                                        userModel.CURR_PROGRAM = actionName;
                                        userModel.CURR_PACKAGE = controllerName;

                                        if (!actionName.Equals("DOMAIN") && !actionName.Equals("WELCOME")
                                            && !actionName.Substring(0, 3).Equals("QRY")
                                            && !actionName.Substring(0, 2).Equals("TX")
                                            && !actionName.Substring(0, 5).Equals("EXCEL")
                                            && !actionName.Substring(0, 3).Equals("PDF"))
                                        {
                                            //if (!userModel.CURR_DOMAIN.Equals("") && !userModel.CURR_PACKAGE.Equals(""))
                                            //{
                                            string DOMAIN_NO = "", PACK_NO = "", PRO_NO = "", FUN_CODE = "";

                                            if (this.HttpContext.Session["USER_MENU"] != null)
                                            {
                                                XmlDocument xmldoc = new XmlDocument();
                                                xmldoc.LoadXml(this.HttpContext.Session["USER_PROGRAM"].ToString());

                                                XmlNodeList ns = xmldoc.SelectNodes("//root/USER_PROGRAM");
                                                foreach (XmlNode node in ns)
                                                {
                                                    PRO_NO = node.SelectSingleNode("PRO_NO").InnerText.ToString();
                                                    PACK_NO = node.SelectSingleNode("PACK_NO").InnerText.ToString();
                                                    DOMAIN_NO = node.SelectSingleNode("DOMAIN_NO").InnerText.ToString();
                                                    FUN_CODE = node.SelectSingleNode("FUN_CODE").InnerText.ToString();
                                                    if (userModel.CURR_PROGRAM.IndexOf(PRO_NO) > -1)
                                                    {
                                                        userModel.CURR_PROGRAM_NAME = node.SelectSingleNode("PRO_NAME_CH").InnerText.ToString();
                                                        userModel.CURR_PACKAGE = PACK_NO;
                                                        userModel.CURR_PACKAGE_NAME = node.SelectSingleNode("PACK_NAME_CH").InnerText.ToString();
                                                        userModel.CURR_DOMAIN = DOMAIN_NO;
                                                        userModel.CURR_DOMAIN_NAME = node.SelectSingleNode("DOMAIN_NAME_CH").InnerText.ToString();
                                                        userModel.FUN_CODE = FUN_CODE;
                                                        break;
                                                    }
                                                }

                                                if (this.HttpContext.Session["USER_ID"].ToString().Trim() == "0") { userModel.FUN_CODE = "ALL"; }

                                            }
                                            //}
                                        }
                                        #endregion
                                    }
                                    catch (MyException e1)
                                    {
                                        //this.HttpContext.Response.Redirect("~/Error.cshtml");
                                        Console.WriteLine(e1.Message);
                                    }


                                    //UserState userState = this.HttpContext.Session["UserState"] as UserState;
                                    //string passCode = this.HttpContext.Request.Cookies["UserState"].Value.Trim();

                                    //实现Action操作权限验证业务                
                                    //userState.AuthCollection.Contains(controllerName + "/" + acitonName);            
                                }
                                else
                                {
                                    //非登录用户跳转                                    
                                    this.HttpContext.Response.Redirect("~/");
                                }
                            }
                            else
                            {
                                //非登录用户跳转                
                                this.HttpContext.Response.Redirect("~/");
                            }
                            break;
                    }
                }
            }
        }

        protected override void Execute(System.Web.Routing.RequestContext requestContext)
        {
            base.Execute(requestContext);
            //this.OnInit();            
        }

        protected override void ExecuteCore()
        {
            base.ExecuteCore();
            //this.OnInit();            
        }

        protected override void Initialize(System.Web.Routing.RequestContext requestContext)
        {
            base.Initialize(requestContext);
            this.OnInit();             
        }

        protected override void OnActionExecuting(System.Web.Mvc.ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);

            //BaseController controller = (BaseController)filterContext.Controller;
            //controller.SetModel(userModel);
            //filterContext.Controller.ViewData.Model = new BaseViewModel(); ;
            //this.OnInit();            
        }



        protected override void OnAuthorization(System.Web.Mvc.AuthorizationContext filterContext)
        {
            base.OnAuthorization(filterContext);
            //this.OnInit();            
        }

        public static string JsonCharFilter(string sourceStr)
        {
            sourceStr = sourceStr.Replace("\\", "\\\\");
            sourceStr = sourceStr.Replace("\b", "\\\b");
            sourceStr = sourceStr.Replace("\t", "\\\t");
            sourceStr = sourceStr.Replace("\n", "\\\n");
            sourceStr = sourceStr.Replace("\n", "\\\n");
            sourceStr = sourceStr.Replace("\f", "\\\f");
            sourceStr = sourceStr.Replace("\r", "\\\r");
            return sourceStr.Replace("\"", "\\\"");
        }

        #region //GetPdfCompanyTitle
        public PdfPTable GetPdfCompanyTitle(string ReportName, bool bNameEN, bool bAddCH, bool bAddEN, bool bTel, string sPageNumber)
        {
            BaseFont bfChinese = BaseFont.CreateFont(@"C:\Windows\Fonts\SIMLI.TTF", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font font15 = new iTextSharp.text.Font(bfChinese, 15, 1);//單頭
            iTextSharp.text.Font font14 = new iTextSharp.text.Font(bfChinese, 14, 0);//正文標題
            iTextSharp.text.Font font12 = new iTextSharp.text.Font(bfChinese, 12, 0);//正文標題
            iTextSharp.text.Font font10 = new iTextSharp.text.Font(bfChinese, 10, 0);//正文標題

            string sParam = "<root><COMPANY_INFO>";
            sParam += "<COMPANY_ID>1</COMPANY_ID>";
            sParam += "<STATUS_NO></STATUS_NO>";
            sParam += "<COMPANY_NO></COMPANY_NO>";
            sParam += "</COMPANY_INFO>";
            sParam += "</root>";
            DataSet oCompany = web.ctEnumerateData("BASSO.QryCompanyInfo001", sParam);

            PdfPTable tblTitle = new PdfPTable(3);
            tblTitle.WidthPercentage = 100;

            // //0=Left, 1=Center, 2=Right
            string str = oCompany.Tables[0].Rows[0]["COMPANY_NAME_CH"].ToString();
            PdfPCell cell = new PdfPCell(new Phrase(str, font15));
            cell.HorizontalAlignment = 1;
            cell.MinimumHeight = 25;
            cell.Colspan = 3;
            cell.Rowspan = 2;
            cell.Border = 0;
            tblTitle.AddCell(cell);

            if (bNameEN)
            {
                str = oCompany.Tables[0].Rows[0]["COMPANY_NAME_EN"].ToString();
                cell = new PdfPCell(new Phrase(str, font12));
                cell.MinimumHeight = 20;
                cell.Rowspan = 2;
                cell.HorizontalAlignment = 1;
                cell.Colspan = 3;
                cell.Border = 0;
                tblTitle.AddCell(cell);
            }

            if (bAddCH)
            {
                str = "地址：" + oCompany.Tables[0].Rows[0]["ADDRESS_CH"].ToString();
                cell = new PdfPCell(new Phrase(str, font10));
                cell.HorizontalAlignment = 0;
                cell.Colspan = 3;
                cell.Border = 0;
                tblTitle.AddCell(cell);
            }

            if (bAddEN)
            {
                str = oCompany.Tables[0].Rows[0]["ADDRESS_EN"].ToString();
                if (!str.Equals(""))
                {
                    cell = new PdfPCell(new Phrase("Address:" + str, font10));
                    cell.HorizontalAlignment = 0;
                    cell.Colspan = 3;
                    cell.Border = 0;
                }
            }

            if (bTel)
            {
                str = "電話：" + oCompany.Tables[0].Rows[0]["TEL_NO"].ToString();
                cell = new PdfPCell(new Phrase(str, font10));
                cell.HorizontalAlignment = 0;
                cell.Border = 0;
                tblTitle.AddCell(cell);

                str = "傳真：" + oCompany.Tables[0].Rows[0]["FAX_NO"].ToString();
                cell = new PdfPCell(new Phrase(str, font10));
                cell.HorizontalAlignment = 0;
                cell.Border = 0;
                tblTitle.AddCell(cell);

                str = "";
                cell = new PdfPCell(new Phrase(str, font10));
                cell.HorizontalAlignment = 0;
                cell.Border = 0;
                tblTitle.AddCell(cell);
            }


            //報表名稱
            cell = new PdfPCell(new Phrase(ReportName, font14));
            cell.MinimumHeight = 18;
            cell.HorizontalAlignment = 1;
            cell.Colspan = 3;
            cell.Border = 0;
            tblTitle.AddCell(cell);

            //打印時間
            cell = new PdfPCell(new Phrase("打印時間:" + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), font10));
            cell.HorizontalAlignment = 0;
            cell.Border = 0;
            tblTitle.AddCell(cell);

            cell = new PdfPCell(new Phrase("打印人員:" + Session["LOGIN_NAME"].ToString().Trim(), font10));
            cell.HorizontalAlignment = 0;
            cell.Border = 0;
            tblTitle.AddCell(cell);

            cell = new PdfPCell(new Phrase(sPageNumber, font10));
            cell.HorizontalAlignment = 2;
            cell.Border = 0;
            tblTitle.AddCell(cell);

            //直線
            cell = new PdfPCell(new Phrase("", font10));
            cell.HorizontalAlignment = 0;
            cell.Colspan = 3;
            cell.Border = 1;
            cell.BorderWidthBottom = (float)0.3;
            cell.BorderWidthLeft = (float)0.0;
            cell.BorderWidthRight = (float)0.0;
            cell.BorderWidthTop = (float)0.0;

            tblTitle.AddCell(cell);


            return tblTitle;
        }
        #endregion

        #region //GetPdfFooter
        public PdfPTable GetPdfFooter(string[] ArrFooter)
        {
            BaseFont bfChinese = BaseFont.CreateFont(@"C:\Windows\Fonts\SIMLI.TTF", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font font10 = new iTextSharp.text.Font(bfChinese, 10, 0);//正文標題


            PdfPTable tblTitle = new PdfPTable(ArrFooter.Length);
            tblTitle.WidthPercentage = 100;

            //直線
            string str = "";
            PdfPCell cell = new PdfPCell(new Phrase(str, font10));
            cell.HorizontalAlignment = 0;
            cell.Colspan = ArrFooter.Length;
            cell.Border = 1;
            cell.BorderWidthBottom = (float)0.3;
            cell.BorderWidthLeft = (float)0.0;
            cell.BorderWidthRight = (float)0.0;
            cell.BorderWidthTop = (float)0.0;
            tblTitle.AddCell(cell);


            //空白一行
            str = " ";
            cell = new PdfPCell(new Phrase(str, font10));
            cell.HorizontalAlignment = 1;
            cell.Colspan = ArrFooter.Length;
            cell.Border = 0;
            tblTitle.AddCell(cell);

            for (int i = ArrFooter.Length - 1; i >= 0; i--)
            {
                str = ArrFooter[i];
                cell = new PdfPCell(new Phrase(str, font10));
                cell.MinimumHeight = 50;
                cell.HorizontalAlignment = 1;
                cell.Border = 0;
                tblTitle.AddCell(cell);

            }
            return tblTitle;
        }
        #endregion

        #region //ConvertToChinese
        public string ConvertToChinese(double x)
        {
            string s = x.ToString("#L#E#D#C#K#E#D#C#J#E#D#C#I#E#D#C#H#E#D#C#G#E#D#C#F#E#D#C#.0B0A");
            string d = Regex.Replace(s, @"((?<=-|^)[^1-9]*)|((?'z'0)[0A-E]*((?=[1-9])|(?'-z'(?=[F-L\.]|$))))|((?'b'[F-L])(?'z'0)[0A-L]*((?=[1-9])|(?'-z'(?=[\.]|$))))", "${b}${z}");
            return Regex.Replace(d, ".", m => "负元空零壹贰叁肆伍陆柒捌玖空空空空空空空分角拾佰仟萬億兆京垓秭穰"[m.Value[0] - '-'].ToString());
        }
        #endregion

        #region //GetExcelData
        public MemoryStream GetExcelData(DataSet oDSData, DataTable dtCol)
        {
            MemoryStream ms = new MemoryStream();
            HSSFWorkbook workbook = new HSSFWorkbook();
            HSSFSheet sheet1 = (HSSFSheet)workbook.CreateSheet("Report");

            #region //Set Font
            HSSFFont fonthead = (HSSFFont)workbook.CreateFont();
            fonthead.FontHeightInPoints = 10;//字号
            fonthead.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.BOLD;//粗体

            HSSFFont font1 = (HSSFFont)workbook.CreateFont();
            font1.FontHeightInPoints = 10;//字号
            #endregion

            #region //Set Style
            HSSFDataFormat format = (HSSFDataFormat)workbook.CreateDataFormat();
            HSSFCellStyle stTitle = (HSSFCellStyle)workbook.CreateCellStyle();
            stTitle.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.YELLOW.index2;//背景色黄色
            stTitle.FillPattern = NPOI.SS.UserModel.FillPatternType.SOLID_FOREGROUND;
            stTitle.SetFont(fonthead);

            HSSFCellStyle stHead = (HSSFCellStyle)workbook.CreateCellStyle();
            stHead.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.YELLOW.index2;//背景色黄色
            stHead.FillPattern = NPOI.SS.UserModel.FillPatternType.SOLID_FOREGROUND;
            stHead.Alignment = NPOI.SS.UserModel.HorizontalAlignment.CENTER;//居中对齐
            stHead.BorderTop = NPOI.SS.UserModel.CellBorderType.THIN;//边框类型
            stHead.BorderRight = NPOI.SS.UserModel.CellBorderType.THIN;
            stHead.BorderBottom = NPOI.SS.UserModel.CellBorderType.THIN;
            stHead.BorderLeft = NPOI.SS.UserModel.CellBorderType.THIN;
            stHead.SetFont(fonthead);

            HSSFCellStyle stItem = (HSSFCellStyle)workbook.CreateCellStyle();
            stItem.Alignment = NPOI.SS.UserModel.HorizontalAlignment.LEFT;//靠左对齐
            stItem.BorderTop = NPOI.SS.UserModel.CellBorderType.THIN;//边框类型
            stItem.BorderRight = NPOI.SS.UserModel.CellBorderType.THIN;
            stItem.BorderBottom = NPOI.SS.UserModel.CellBorderType.THIN;
            stItem.BorderLeft = NPOI.SS.UserModel.CellBorderType.THIN;
            stItem.SetFont(font1);

            #region //DateTime Format
            HSSFCellStyle stDate = (HSSFCellStyle)workbook.CreateCellStyle();
            stDate.Alignment = NPOI.SS.UserModel.HorizontalAlignment.CENTER;//居中对齐
            stDate.BorderTop = NPOI.SS.UserModel.CellBorderType.THIN;//边框类型
            stDate.BorderRight = NPOI.SS.UserModel.CellBorderType.THIN;
            stDate.BorderBottom = NPOI.SS.UserModel.CellBorderType.THIN;
            stDate.BorderLeft = NPOI.SS.UserModel.CellBorderType.THIN;
            stDate.DataFormat = format.GetFormat("yyyy-MM-dd");
            stDate.SetFont(font1);

            HSSFCellStyle stDateTime = (HSSFCellStyle)workbook.CreateCellStyle();
            stDateTime.Alignment = NPOI.SS.UserModel.HorizontalAlignment.CENTER;//居中对齐
            stDateTime.BorderTop = NPOI.SS.UserModel.CellBorderType.THIN;//边框类型
            stDateTime.BorderRight = NPOI.SS.UserModel.CellBorderType.THIN;
            stDateTime.BorderBottom = NPOI.SS.UserModel.CellBorderType.THIN;
            stDateTime.BorderLeft = NPOI.SS.UserModel.CellBorderType.THIN;
            stDateTime.DataFormat = format.GetFormat("yyyy-MM-dd HH:mm:ss");
            stDateTime.SetFont(font1);
            #endregion


            #region //Number Format
            HSSFCellStyle stNum0 = (HSSFCellStyle)workbook.CreateCellStyle();
            stNum0.Alignment = NPOI.SS.UserModel.HorizontalAlignment.RIGHT;//靠右对齐
            stNum0.BorderTop = NPOI.SS.UserModel.CellBorderType.THIN;//边框类型
            stNum0.BorderRight = NPOI.SS.UserModel.CellBorderType.THIN;
            stNum0.BorderBottom = NPOI.SS.UserModel.CellBorderType.THIN;
            stNum0.BorderLeft = NPOI.SS.UserModel.CellBorderType.THIN;
            stNum0.DataFormat = format.GetFormat("0");
            stNum0.SetFont(font1);

            HSSFCellStyle stNum2 = (HSSFCellStyle)workbook.CreateCellStyle();
            stNum2.Alignment = NPOI.SS.UserModel.HorizontalAlignment.RIGHT;//靠右对齐
            stNum2.BorderTop = NPOI.SS.UserModel.CellBorderType.THIN;//边框类型
            stNum2.BorderRight = NPOI.SS.UserModel.CellBorderType.THIN;
            stNum2.BorderBottom = NPOI.SS.UserModel.CellBorderType.THIN;
            stNum2.BorderLeft = NPOI.SS.UserModel.CellBorderType.THIN;
            stNum2.DataFormat = HSSFDataFormat.GetBuiltinFormat("0.00");
            stNum2.SetFont(font1);

            HSSFCellStyle stNum5 = (HSSFCellStyle)workbook.CreateCellStyle();
            stNum5.Alignment = NPOI.SS.UserModel.HorizontalAlignment.RIGHT;//靠右对齐
            stNum5.BorderTop = NPOI.SS.UserModel.CellBorderType.THIN;//边框类型
            stNum2.BorderRight = NPOI.SS.UserModel.CellBorderType.THIN;
            stNum5.BorderBottom = NPOI.SS.UserModel.CellBorderType.THIN;
            stNum5.BorderLeft = NPOI.SS.UserModel.CellBorderType.THIN;
            stNum5.DataFormat = format.GetFormat("0.00000");
            stNum5.SetFont(font1);
            #endregion

            #endregion

            #region //Excel Title
            HSSFRow row1 = (HSSFRow)sheet1.CreateRow(0);
            row1.Height = 20 * 20;
            for (int nC = 0; nC < dtCol.Rows.Count; nC++)
            {
                HSSFCell cellhead1 = (HSSFCell)row1.CreateCell(nC);
                cellhead1.SetCellValue(dtCol.Rows[nC]["ColDisplay"].ToString().Trim());
                cellhead1.CellStyle = stHead;
            }
            #endregion

            #region //Loop to item
            int i = 1;
            foreach (DataRow dr in oDSData.Tables[0].Rows)
            {
                HSSFRow row = (HSSFRow)sheet1.CreateRow(i);
                row.Height = 15 * 20;
                for (int j = 0; j < dtCol.Rows.Count; j++)
                {
                    HSSFCell cell = (HSSFCell)row.CreateCell(j);
                    switch (dtCol.Rows[j]["ColType"].ToString().Trim())
                    {
                        case "Double0":
                            if (dr[dtCol.Rows[j]["ColName"].ToString().Trim()].ToString().Trim().Equals(""))
                            {
                                cell.SetCellValue(0.0);
                            }
                            else
                            {
                                cell.SetCellValue(double.Parse(dr[dtCol.Rows[j]["ColName"].ToString().Trim()].ToString()));
                            }
                            cell.CellStyle = stNum0;
                            break;
                        case "Double2":
                            if (dr[dtCol.Rows[j]["ColName"].ToString().Trim()].ToString().Trim().Equals(""))
                            {
                                cell.SetCellValue(0.00);
                            }
                            else
                            {
                                cell.SetCellValue(double.Parse(dr[dtCol.Rows[j]["ColName"].ToString().Trim()].ToString()));
                            }
                            cell.CellStyle = stNum2;
                            break;
                        case "Double5":
                            if (dr[dtCol.Rows[j]["ColName"].ToString().Trim()].ToString().Trim().Equals(""))
                            {
                                cell.SetCellValue(0.0000);
                            }
                            else
                            {
                                cell.SetCellValue(double.Parse(dr[dtCol.Rows[j]["ColName"].ToString().Trim()].ToString()));
                            }
                            cell.CellStyle = stNum5;
                            break;
                        case "Date":
                            if (dr[dtCol.Rows[j]["ColName"].ToString().Trim()].ToString().Trim().Equals(""))
                            {
                                cell.SetCellValue("");
                            }
                            else
                            {
                                cell.SetCellValue(DateTime.Parse(dr[dtCol.Rows[j]["ColName"].ToString().Trim()].ToString()));
                            }
                            cell.CellStyle = stDate;
                            break;
                        case "DateTime":
                            if (dr[dtCol.Rows[j]["ColName"].ToString().Trim()].ToString().Trim().Equals(""))
                            {
                                cell.SetCellValue("");
                            }
                            else
                            {
                                cell.SetCellValue(DateTime.Parse(dr[dtCol.Rows[j]["ColName"].ToString().Trim()].ToString()));
                            }
                            cell.CellStyle = stDateTime;
                            break;
                        default:
                            cell.SetCellValue(cmn.cap_string(dr[dtCol.Rows[j]["ColName"].ToString().Trim()]));
                            cell.CellStyle = stItem;
                            break;
                    }
                }
                i++;
            }
            #endregion

            workbook.Write(ms);
            workbook = null;
            ms.Close();
            ms.Dispose();

            return ms;
        }
        #endregion

        #region //cap_log
        public static void cap_log(string LogStr)
        {
            StreamWriter sw = null;
            try
            {
                string LogPath = System.Configuration.ConfigurationManager.AppSettings["CONNECTION_PATH"] + @"\LOG\";
                if (!Directory.Exists(LogPath)) { Directory.CreateDirectory(LogPath); }

                LogStr = DateTime.Now.ToLocalTime().ToString() + " -- " + LogStr;
                sw = new StreamWriter(LogPath + DateTime.Now.ToString("yyyyMMdd") + ".txt", true);
                sw.WriteLine(LogStr);
            }
            catch
            {
            }
            finally
            {
                if (sw != null)
                {
                    sw.Close();
                }
            }
        }
        #endregion
    }
}