﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using MESIII;

namespace SYSSO
{
    public class Transaction : ISDServer.ITransaction
    {
        public int Execute(IProcess oContext, string sServiceID, string sParams, TxTypeConsts nTxType, int nServerID, object Options)
        {
            try
            {
                TArgsTX oArgsTx = new TArgsTX();
                oArgsTx.ServiceID = sServiceID;
                oArgsTx.Param = sParams;
                oArgsTx.Context = oContext;
                oArgsTx.Connecion = oContext.CNEstablish("SYSSO", nServerID);
                oArgsTx.Command = oContext.CMD("SYSSO", nServerID);
                oArgsTx.ServerID = nServerID;
                oArgsTx.TxType = nTxType;
                oArgsTx.Result = -1;
                int nReslut = 0;
                //****************************************************************
                oContext.TxBegin("SYSSO", nServerID);
                //****************************************************************
                SYSTx Tx = new SYSTx();
                //****************************************************************
                switch (sServiceID)
                {
                    case "TxTraceInfo001": nReslut = Tx.TxTraceInfo001(oArgsTx); break;
                    case "TxDomainInfo001": nReslut = Tx.TxDomainInfo001(oArgsTx); break;

                    default: throw new SystemException("Unkown transaction specifier [ " + sServiceID + " ]");
                }
                //****************************************************************			
                oContext.TxCommit("BASSO", nServerID);
                return nReslut;
            }
            catch (MyException e)
            {
                oContext.TxRollback("BASSO", nServerID);
                throw e;
            }
        }
    }

    class SYSTx
    {
        CmnSrvLib cmn = new CmnSrvLib(0);
        ISDServer srv = new ISDServer();
        int nResult = 0;
        string sql = "", tx = "";

        #region //TxTraceInfo001 -- TRACE_INFO DATA MAINTAIN -- boly 2016-01-01
        public int TxTraceInfo001(TArgsTX oArgsTx)
        {
            OleDbCommand cmd = oArgsTx.Command;
            int nUserID = oArgsTx.Context.UserID();
            tx = oArgsTx.ServiceID;
            //******************************************************************
            XmlDocument x = new XmlDocument();
            x.LoadXml(oArgsTx.Param);
            int USER_ID = cmn.ParserXML(x, "//TRACE_INFO/USER_ID", -999);
            string PRO_NO = cmn.ParserXML(x, "//TRACE_INFO/PRO_NO");
            string SERVICE_NAME = cmn.ParserXML(x, "//TRACE_INFO/SERVICE_NAME");
            string SERVICE_TYPE = cmn.ParserXML(x, "//TRACE_INFO/SERVICE_TYPE");
            string CLIENT_IP = cmn.ParserXML(x, "//TRACE_INFO/CLIENT_IP");
            string SESSION_ID = cmn.ParserXML(x, "//TRACE_INFO/SESSION_ID");
            //******************************************************************
            if (USER_ID < -1) { throw new MyException(999, tx, "FIELD [ USER_ID ] CANNOT EMPTY!!"); }
            if (SESSION_ID.Equals("")) { throw new MyException(999, tx, "FIELD [ SESSION_ID ] CANNOT EMPTY!!"); }

            switch (oArgsTx.TxType)
            {
                case TxTypeConsts.TxTypeAddNew:
                    if (CLIENT_IP.Equals("")) { throw new MyException(999, tx, "FIELD [ CLIENT_IP ] CANNOT EMPTY!!"); }

                    sql = "INSERT INTO BAS.TRACE_INFO(USER_ID,PRO_NO,SERVICE_NAME,SERVICE_TYPE";
                    sql += ",CLIENT_IP,SESSION_ID,LOGIN_TIME,CREATE_DATE)";
                    sql += " VALUES(" + cmn.SQLQC(USER_ID) + cmn.SQLQC(PRO_NO) + cmn.SQLQC(SERVICE_NAME) + cmn.SQLQC(SERVICE_TYPE);
                    sql += cmn.SQLQC(CLIENT_IP) + cmn.SQLQC(SESSION_ID);
                    sql += cmn.SQLQC(DateTime.Now) + cmn.SQLQ(DateTime.Now) + ")";
                    nResult = cmn.CmnExecute(sql, cmd);
                    break;
                //************************************************************
                case TxTypeConsts.TxTypeDelete:
                    break;
                //************************************************************
                case TxTypeConsts.TxTypeUpdate:
                    sql = "UPDATE BAS.TRACE_INFO SET LOGOUT_TIME = " + cmn.SQLQ(DateTime.Now);
                    sql += " WHERE USER_ID = " + cmn.SQLQ(USER_ID);
                    sql += " AND SESSION_ID = " + cmn.SQLQ(SESSION_ID);
                    nResult = cmn.CmnExecute(sql, cmd);
                    break;
                //************************************************************
                case TxTypeConsts.TxTypeChange:
                    break;
            }
            return nResult;
        }
        #endregion     

        #region //TxDomainInfo001 -- DOMAIN_INFO DATA MAINTAIN -- boly 2016-01-01
        public int TxDomainInfo001(TArgsTX oArgsTx)
        {
            OleDbCommand cmd = oArgsTx.Command;
            int nUserID = oArgsTx.Context.UserID();
            tx = oArgsTx.ServiceID;
            //***********************************************************************
            XmlDocument x = new XmlDocument();
            x.LoadXml(oArgsTx.Param);
            string DOMAIN_NO = cmn.ParserXML(x, "//DOMAIN_INFO/DOMAIN_NO");
            string DOMAIN_NAME_CH = cmn.ParserXML(x, "//DOMAIN_INFO/DOMAIN_NAME_CH");
            string DOMAIN_NAME_EN = cmn.ParserXML(x, "//DOMAIN_INFO/DOMAIN_NAME_EN");
            int DOMAIN_SEQ = cmn.ParserXML(x, "//DOMAIN_INFO/DOMAIN_SEQ", -1);
            //***********************************************************************
            if (DOMAIN_NO.Equals("")) { throw new MyException(999, tx, "FIELD [ DOMAIN NO ] CANNOT EMPTY!!"); }
            if (DOMAIN_NAME_CH.Equals("")) { throw new MyException(999, tx, "FIELD [ DOMAIN NAME CH ] CANNOT EMPTY!!"); }

            switch (oArgsTx.TxType)
            {
                case TxTypeConsts.TxTypeAddNew:
                    sql = "INSERT BAS.DOMAIN_INFO(DOMAIN_NO,DOMAIN_NAME_CH,DOMAIN_NAME_EN,DOMAIN_SEQ";
                    sql += ",CREATE_USERID,UPDATE_USERID,CREATE_DATE,UPDATE_DATE)";
                    sql += " VALUES (" + cmn.SQLQC(DOMAIN_NO) + cmn.SQLQC(DOMAIN_NAME_CH) + cmn.SQLQC(DOMAIN_NAME_EN, null) + cmn.SQLQC(DOMAIN_SEQ);
                    sql += cmn.SQLQC(nUserID) + cmn.SQLQC(nUserID) + cmn.SQLQC(DateTime.Now) + cmn.SQLQ(DateTime.Now) + ")";
                    nResult = cmn.CmnExecute(sql, cmd);
                    break;
                //***********************************************************************
                case TxTypeConsts.TxTypeDelete:
                    break;
                //***********************************************************************
                case TxTypeConsts.TxTypeUpdate:
                    sql = "UPDATE BAS.DOMAIN_INFO SET DOMAIN_NAME_CH = " + cmn.SQLQC(DOMAIN_NAME_CH);
                    sql += "DOMAIN_NAME_EN = " + cmn.SQLQC(DOMAIN_NAME_EN, null);
                    sql += "DOMAIN_SEQ = " + cmn.SQLQC(DOMAIN_SEQ);
                    sql += "UPDATE_USERID = " + cmn.SQLQC(nUserID);
                    sql += "UPDATE_DATE = " + cmn.SQLQ(DateTime.Now);
                    sql += " WHERE DOMAIN_NO = " + cmn.SQLQ(DOMAIN_NO);
                    nResult = cmn.CmnExecute(sql, cmd);
                    break;
                //***********************************************************************
                case TxTypeConsts.TxTypeChange:
                    break;
                //***********************************************************************
            }
            return nResult;
        }
        #endregion
    }
}
