﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TEMP001.Models
{
    public class UserModel
    {
        private string msAddnew = "", msUpdate = "", msDelete = "", msChange = "", msFunCode = "";
        private string msApprove = "N";//1:核准
        private string msConfirm = "N";//2:確認
        private string msPost = "N";//3:過帳
        private string msSend = "N";//4:送審
        private string msPrint = "N";//5:打印

        public int USER_ID { get; set; }
        public string LOGIN_NO { get; set; }
        public string LOGIN_NAME_CH { get; set; }
        public string LOGIN_NAME_EN { get; set; }
        public string LOGIN_PWD { get; set; }
        public string VAILD_CODE { get; set; }
        public string GUI_LANGUAGE { get; set; }
        public string USER_MENU { get; set; }

        public string USER_DOMAIN { get; set; }
        public string USER_PACKAGE { get; set; }
        public string USER_PROGRAM { get; set; }

        public string CURR_DOMAIN { get; set; }
        public string CURR_DOMAIN_NAME { get; set; }
        public string CURR_PACKAGE { get; set; }
        public string CURR_PACKAGE_NAME { get; set; }
        public string CURR_PROGRAM { get; set; }
        public string CURR_PROGRAM_NAME { get; set; }

        public string FUN_CODE { get { return msFunCode; } set { msFunCode = value; } }
        public string Addnew { get { return msAddnew; } set { msAddnew = value; } }
        public string Update { get { return msUpdate; } set { msUpdate = value; } }
        public string Delete { get { return msDelete; } set { msDelete = value; } }
        public string Change { get { return msChange; } set { msChange = value; } }

        public string FApprove { get { return msApprove; } set { msApprove = value; } }
        public string FConfirm { get { return msConfirm; } set { msConfirm = value; } }
        public string FPost { get { return msPost; } set { msPost = value; } }
        public string FSend { get { return msSend; } set { msSend = value; } }
        public string FPrint { get { return msPrint; } set { msPrint = value; } }

        public string CLIENT_IP { get; set; }
        public string MESSAGE { get; set; }
    }
}