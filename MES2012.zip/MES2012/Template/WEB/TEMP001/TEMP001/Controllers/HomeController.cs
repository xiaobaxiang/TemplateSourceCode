﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MESIII;

namespace TEMP001.Controllers
{
    public class HomeController : BaseController
    {       
        public ActionResult Index()
        {
            return View(userModel);
        }

        public ActionResult Welcome()
        {
            return View(userModel);
        }

        #region //TxLogin
        public void TxLogin()
        {
            string sLoginNO = Request["LOGIN_NO"].ToString().Trim();
            string sPassword = Request["LOGIN_PWD"].ToString().Trim();
            //string TEMP_CODE = Request["VAILD_CODE"].ToString().Trim();
            int nServerID = int.Parse(Session["SERVER_ID"].ToString());
            string VAILD_CODE = Session["VAILD_CODE"].ToString();
            CmnSrvLib cmn = new CmnSrvLib();
            string res = "";

            try
            {
                //if (!TEMP_CODE.Equals(VAILD_CODE)) { throw new MyException(991, "TxLogin", "VAILD CODE ERROR!"); }

                string sParam = "<root><LOGIN_INFO>";
                sParam += "<LOGIN_NO>" + sLoginNO + "</LOGIN_NO>";
                sParam += "<LOGIN_PWD>" + sPassword + "</LOGIN_PWD>";
                sParam += "<CLIENT_SESSION>" + Session.SessionID + "</CLIENT_SESSION>";
                sParam += "<CLIENT_IP>" + Session["CLIENT_IP"].ToString() + "</CLIENT_IP>";
                sParam += "</LOGIN_INFO></root>";
                ISDClient client = new ISDClient(Convert.ToInt32(Session["SERVER_ID"]));
                DataSet oDS = client.ctEnumerateData("SYSSO.QryLogin001", sParam);
                int USER_ID = cmn.cap_int(oDS.Tables[0].Rows[0]["USER_ID"], -1);
                int ROLE_ID = cmn.cap_int(oDS.Tables[0].Rows[0]["ROLE_ID"], -1);
                string USER_NAME_CH = cmn.cap_string(oDS.Tables[0].Rows[0]["USER_NAME_CH"]);
                string USER_NAME_EN = cmn.cap_string(oDS.Tables[0].Rows[0]["USER_NAME_EN"]);
                string ROLE_NAME_CH = cmn.cap_string(oDS.Tables[0].Rows[0]["ROLE_NAME_CH"]);
                string ROLE_NAME_EN = cmn.cap_string(oDS.Tables[0].Rows[0]["ROLE_NAME_EN"]);
                int LOGIN_COUNT = cmn.cap_int(oDS.Tables[0].Rows[0]["LOGIN_COUNT"], 0);
                string LOGIN_TIME = cmn.cap_datetime(oDS.Tables[0].Rows[0]["LOGIN_TIME"]);

                Session["Authenticated"] = true;
                Session["LOGIN_NO"] = sLoginNO;
                Session["USER_ID"] = USER_ID;
                Session["LOGIN_NAME"] = USER_NAME_CH;
                Session["ROLE_ID"] = ROLE_ID;
                Session["ROLE_NAME"] = ROLE_NAME_CH;
                Session["LOGIN_COUNT"] = LOGIN_COUNT;
                Session["LOGIN_TIME"] = LOGIN_TIME;

                sParam = "<root><USER_DOMAIN>";
                sParam += "<USER_ID>" + USER_ID + "</USER_ID>";
                sParam += "</USER_DOMAIN></root>";
                oDS = client.ctEnumerateData("SYSSO.QryUserDomain001", sParam, -1, -1);
                Session["USER_DOMAIN"] = oDS.GetXml();
                //Session["USER_DOMAIN"] = CmnSrvLib.Dtb2Json(oDS.Tables["USER_DOMAIN"]).ToString();

                sParam = "<root><USER_PACKAGE>";
                sParam += "<USER_ID>" + USER_ID + "</USER_ID>";
                sParam += "<DOMAIN_NO></DOMAIN_NO>";
                sParam += "</USER_PACKAGE></root>";
                oDS = client.ctEnumerateData("SYSSO.QryUserPackage001", sParam, -1, -1);
                Session["USER_PACKAGE"] = oDS.GetXml();
                //Session["USER_PACKAGE"] = CmnSrvLib.Dtb2Json(oDS.Tables["USER_PACKAGE"]).ToString();

                sParam = "<root><USER_PROGRAM>";
                sParam += "<USER_ID>" + USER_ID + "</USER_ID>";
                sParam += "<PACK_NO></PACK_NO>";
                sParam += "</USER_PROGRAM></root>";
                oDS = client.ctEnumerateData("SYSSO.QryUserProgram001", sParam, -1, -1);
                Session["USER_PROGRAM"] = oDS.GetXml();
                //Session["USER_PROGRAM"] = CmnSrvLib.Dtb2Json(oDS.Tables["USER_PROGRAM"]).ToString();

                res = "{\"status\" : \"OK\",\"msg\": \"OK\",\"qrydata\":\"" + Url.Action("Welcome", "Home") + "\"}";
            }
            catch (Exception e1)
            {
                res = "{\"status\" : \"error\",\"msg\": \"error\",\"error_desc\":\"" + e1.Message + "\"}";
            }

            Response.Write(res);
        }
        #endregion //TxLogin END
    }
}
