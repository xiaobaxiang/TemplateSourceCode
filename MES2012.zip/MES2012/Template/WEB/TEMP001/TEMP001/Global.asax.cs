﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using TEMP001.Controllers;

namespace TEMP001
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            WebApiConfig.Register(GlobalConfiguration.Configuration);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }

        protected void Application_Error(Object sender, EventArgs e)
        {
            Exception lastError = Server.GetLastError();
            //TEMP001.BaseController.cap_log(lastError.Message);
            Server.ClearError();

            int statusCode = 0;

            if (lastError.GetType() == typeof(HttpException))
            {
                statusCode = ((HttpException)lastError).GetHttpCode();
            }
            else
            {
                // Not an HTTP related error so this is a problem in our code, set status to
                // 500 (internal server error)
                statusCode = 500;
            }

            HttpContextWrapper contextWrapper = new HttpContextWrapper(this.Context);

            RouteData routeData = new RouteData();
            routeData.Values.Add("controller", "Errors");
            routeData.Values.Add("action", "Index");
            routeData.Values.Add("statusCode", statusCode);
            routeData.Values.Add("exception", lastError);
            routeData.Values.Add("isAjaxRequet", contextWrapper.Request.IsAjaxRequest());

            IController controller = new ErrorsController();

            RequestContext requestContext = new RequestContext(contextWrapper, routeData);

            controller.Execute(requestContext);
            Response.End();

            //Exception lastError = Server.GetLastError();
            //if (lastError != null)
            //{
            //    Server.ClearError();
            //    Response.Redirect("~/Home/NotFound/?message=" + lastError.Message);               
            //}
        }

        protected void Session_Start()
        {
            Session["SERVER_ID"] = 0;
            Session["LANGUAGE"] = "T";

            Session["CLIENT_IP"] = Request.ServerVariables["REMOTE_ADDR"];
            Session["LOCAL_PATH"] = Request.ServerVariables["APPL_PHYSICAL_PATH"];
            Session["APP_DATA"] = Request.ServerVariables["APPL_PHYSICAL_PATH"] + @"\App_Data\";
            Session["HTTP_PATH"] = Request.ServerVariables["SERVER_NAME"] + Request.ApplicationPath;
            Session["SERVER_PATH"] = "http://" + Request.ServerVariables["SERVER_NAME"] + Request.ApplicationPath;
            Session["IMAGE_PATH"] = Session["SERVER_PATH"].ToString() + "/img/";

            Session["AUTHENTICATED"] = false;
            Session["LOGIN_NO"] = "";
            Session["USER_ID"] = -1;
            Session["ROLE_ID"] = -1;
            Session["ROLE_NAME"] = "";
            Session["LOGIN_NAME"] = "";
            Session["LOGIN_TIME"] = "";
            Session["LOGIN_COUNT"] = 0;
            Session["USER_MENU"] = "";
            Session["VAILD_CODE"] = "";
        }
    }
}